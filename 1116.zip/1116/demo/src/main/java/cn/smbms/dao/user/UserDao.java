package cn.smbms.dao.user;

import cn.smbms.beans.User;

import java.util.List;

public interface UserDao {
    // 查询有多少用户
    public int getUserCount();

    // 查询所有用户的信息
    public List<User> getUserList();

}
