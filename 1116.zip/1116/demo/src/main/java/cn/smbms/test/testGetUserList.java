package cn.smbms.test;

import cn.smbms.beans.User;
import cn.smbms.dao.user.UserDao;
import cn.smbms.util.MyBatiesUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.jupiter.api.Test;

import java.util.List;

public class testGetUserList {

    @Test
    public void test01() {
        SqlSession sqlSession = MyBatiesUtil.createSqlSession();
        List<User> userList = sqlSession.selectList("cn.smbms.dao.user.UserDao.getUserList");
        for ( User u : userList ) {
            System.out.println(u.toString());
        }
        MyBatiesUtil.closeSqlSession(sqlSession);

    }

    @Test
    public void test02() {
        SqlSession sqlSession = MyBatiesUtil.createSqlSession();
        List<User> userList = sqlSession.getMapper(UserDao.class).getUserList();
        for ( User u : userList ) {
            System.out.println(u.toString());
        }
        MyBatiesUtil.closeSqlSession(sqlSession);
    }




}
